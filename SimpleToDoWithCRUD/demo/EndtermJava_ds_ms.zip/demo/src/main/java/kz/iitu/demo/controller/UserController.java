package kz.iitu.demo.controller;


import kz.iitu.demo.model.User;
import kz.iitu.demo.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.swing.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Optional;

@Controller
public class UserController {
    private UserRepository userRepository;
    @Autowired
    public UserController(UserRepository userRepository)
    {
        this.userRepository = userRepository;
    }


   @PostMapping("/add")
    public String addNewUser(@RequestParam("name") String name,
                             @RequestParam("password") String password)
    {
        User user = new User();
        DateTimeFormatter form = DateTimeFormatter.ofPattern("yyyy:MM:dd");
        LocalDateTime localDateTime = LocalDateTime.now();
        String date = localDateTime.format(form);
        user.setName(name);
        user.setPassword(password);
        user.setDate(date);
        userRepository.save(user);
        return "index";
    }


    @GetMapping("/users/{id}")
    public @ResponseBody
    User getUser(@PathVariable("id") Integer id)
    {
        return userRepository.findById(id).get();
    }


    @GetMapping("/users")
    public @ResponseBody Iterable<User> getAllUsers()
    {
        return userRepository.findAll();
    }

    @PutMapping("/users/update/{id}")
    User update(@RequestBody User user, @PathVariable Integer id) {

        Optional<User> user1 = userRepository.findById(id);
        User currentUser = user1.get();
        if (currentUser == null) {
            user.setId(id);
            return userRepository.save(user);
        }
        currentUser.setName(user.getName());
        currentUser.setPassword(user.getPassword());

        return userRepository.save(currentUser);
    }


    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable("id") Integer id)
    {
        userRepository.deleteById(id);
    }



}
